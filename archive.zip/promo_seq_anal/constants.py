from pathlib import Path

RESULT_DIR = Path(r'C:\DATA\master-thesis\results')