from functionality.database import *

cpu_test()
